<title>Inspirus 8</title>
<style>
.bgImage {
    background-image: url(images/ok.jpg);
    background-size: cover;
    background-position: center center;
    height: 650px;
    margin-bottom: 25px;
}
</style>
<header class="bgImage" > 
    <nav class="navbar" >
        <div class="container">
        <div class="navbar-header"><!--website name/title-->
               
                <a class = "navbar-brand">
                   <h2>INSPIRUS 8</h2>
                </a>
        </div>
       
            <ul class="nav navbar-nav navbar-right"><!--navigation-->
                    <li><a href = "index.php"><strong>Home</strong></a></li>
                    <li><a href = "contact.php"><strong>Contact Us</strong></a></li>
                    <li><a href = "aboutus.php"><strong>About us</strong></a></li>
                    <li class="btnlogout"><a class = "btn btn-default navbar-btn" href = "login_form.php"> Admin Login <span class = "glyphicon glyphicon-log-in"></span></a></li>

            
                
                
            </ul>
        </div><!--container div-->
    </nav>
    <div class = "col-md-12">
        <div class = "container">
            <div class = "jumbotron"><!--jumbotron-->
                <h1><strong>INSPIRUS 8<br></strong>Make It Happen</h1><!--jumbotron heading-->
                <p style="font-style: bold">Join us for Inspirus 8 on November 10th and 11th, 2024! Presented by C-CODES and the Department of Computer Engineering, this flagship event of Don Bosco College of Engineering brings together participants from across Goa and Neighbouring states to compete and innovate in technology for exciting prizes. Don't miss it!</p>
                <br><div class="browse d-md-flex col-md-14" >
                <div class="row">
                  
            </div>
        </div>
    </div>
</header>