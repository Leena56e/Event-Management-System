<?php
session_start();
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>


<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Inspirus 8</title>
        <?php require 'utils/styles.php'; ?>
    </head>
    <body>
        <?php require 'utils/header.php'; ?> <!--header content. file found in utils folder-->

        <!-- Add Logout Button in Header or Top Navigation -->
        <div style="text-align: right; margin: 10px;">
            <a class="btn btn-danger" href="?logout=true">Logout</a>
        </div>

        <div class="content">
            <div class="container">
                <div class="col-md-12">
                    <h1 style="color:#000080; font-size:42px;"><strong>View Events</strong></h1>
                </div>

                <div class="container">
                    <div class="col-md-12">
                        <hr>
                    </div>
                </div>

                <!-- Technical Events Section -->
                <div class="row">
                    <section>
                        <div class="container">
                            <div class="col-md-6">
                                <img src="images/technical.jpg" class="img-responsive">
                            </div>
                            <div class="subcontent col-md-6">
                                <h1 style="color:#003300; font-size:38px;"><u><strong>Technical Events</strong></u></h1>
                                <p>EMBRACE YOUR TECHNICAL SKILLS BY PARTICIPATING IN OUR DIFFERENT TECHNICAL EVENTS!</p>
                                <br><br>
                                <?php 
                                $id = 1;
                                echo '<a class="btn btn-default" href="viewEvent.php?id=' . $id . '">
                                        <span class="glyphicon glyphicon-circle-arrow-right"></span> View Technical Events
                                      </a>';
                                ?>
                            </div>
                        </div>
                    </section>
                </div>

                <div class="container">
                    <div class="col-md-12">
                        <hr>
                    </div>
                </div>

                <!-- Non-Technical Events Section -->
                <div class="row">
                    <section>
                        <div class="container">
                            <div class="col-md-6">
                                <img src="images/gaming.jpg" class="img-responsive">
                            </div>
                            <div class="subcontent col-md-6">
                                <h1 style="color:#003300; font-size:38px;"><strong><u>Non-Technical Events</u></strong></h1>
                                <p>EMBRACE YOUR NON-TECHNICAL SKILLS BY PARTICIPATING IN OUR DIFFERENT NON-TECHNICAL EVENTS!</p>
                                <br><br>
                                <?php 
                                $id = 2;
                                echo '<a class="btn btn-default" href="viewEvent.php?id=' . $id . '">
                                        <span class="glyphicon glyphicon-circle-arrow-right"></span> View Non-Technical Events
                                      </a>';
                                ?>
                            </div>
                        </div>
                    </section>
                </div>

                <?php require 'utils/footer.php'; ?> <!--footer content. file found in utils folder-->
            </div>
        </div>
    </body>
</html>
