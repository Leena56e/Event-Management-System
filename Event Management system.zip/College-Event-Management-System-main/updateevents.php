<?php
include_once 'classes/db1.php';

// Check if event_id is provided
if (isset($_GET['id'])) {
    $event_id = intval($_GET['id']); // Ensure the ID is an integer
    // Query to fetch event details
    $result = mysqli_query($conn, "SELECT e.event_id, e.event_title, e.participents, e.img_link, ef.Date, ef.time, ef.location 
                                    FROM events e 
                                    JOIN event_info ef ON e.event_id = ef.event_id 
                                    WHERE e.event_id = '$event_id'");

    // Fetch the event details
    $event = mysqli_fetch_assoc($result);
    
    // Check if event exists
    if (!$event) {
        die("Event not found.");
    }
} else {
    die("Invalid request.");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Event - Inspirus 8</title>
    <?php require 'utils/styles.php'; ?>
</head>

<body>
    <?php include 'utils/adminHeader.php'; ?>

    <div class="container">
        <h2>Update Event</h2>
        <form method="POST" action="">
            <input type="hidden" name="event_id" value="<?php echo htmlspecialchars($event['event_id']); ?>">

            <div class="form-group">
                <label>Event Title:</label>
                <input type="text" name="event_title" required class="form-control" value="<?php echo htmlspecialchars($event['event_title']); ?>">
            </div>

            <div class="form-group">
                <label>No. of Participants:</label>
                <input type="number" name="participents" required class="form-control" value="<?php echo htmlspecialchars($event['participents']); ?>">
            </div>

            <div class="form-group">
                <label>Image Link:</label>
                <input type="text" name="img_link" class="form-control" value="<?php echo htmlspecialchars($event['img_link']); ?>">
            </div>

            <div class="form-group">
                <label>Date:</label>
                <input type="date" name="Date" required class="form-control" value="<?php echo htmlspecialchars($event['Date']); ?>">
            </div>

            <div class="form-group">
                <label>Time:</label>
                <input type="time" name="time" required class="form-control" value="<?php echo htmlspecialchars($event['time']); ?>">
            </div>

            <div class="form-group">
                <label>Location:</label>
                <input type="text" name="location" required class="form-control" value="<?php echo htmlspecialchars($event['location']); ?>">
            </div>

            <button type="submit" name="updateEvent" class="btn btn-primary">Update Event</button>
            <a href="adminPage.php" class="btn btn-default">Back to Events</a>
        </form>
    </div>

    <?php
    // Handle form submission
    if (isset($_POST['updateEvent'])) {
        $event_id = $_POST['event_id'];
        $event_title = $_POST['event_title'];
        $participants = $_POST['participents'];
        $img_link = $_POST['img_link'];
        $date = $_POST['Date'];
        $time = $_POST['time'];
        $location = $_POST['location'];

        // Update query for events and event_info
        $updateEvent = "UPDATE events SET event_title = '$event_title', participents = $participants, img_link = '$img_link' WHERE event_id = $event_id";
        $updateEventInfo = "UPDATE event_info SET Date = '$date', time = '$time', location = '$location' WHERE event_id = $event_id";

        // Execute updates
        if (mysqli_query($conn, $updateEvent) && mysqli_query($conn, $updateEventInfo)) {
            echo "<script>alert('Event updated successfully!'); window.location.href='adminPage.php';</script>";
        } else {
            echo "<script>alert('Error updating event: " . mysqli_error($conn) . "');</script>";
        }
    }
    ?>

    <?php include 'utils/footer.php'; ?>
</body>

</html>
