<!DOCTYPE html>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Inspirus 8</title>
<?php require 'utils/styles.php'; ?><!--css links. file found in utils folder-->
</head>
<style>

/* Large rounded green border */
hr.blueline {
  border: 10px solid #00004d;
  border-radius: 5px;
}

#bj
{
  font-size: 22px;
}
</style>



  <?php require 'utils/header.php'; ?>
  <hr class="blueline">
  <div class="col-md-12">
  
<h1>About Us</h1>

<p>  The Fatorda Salesians Society's DON BOSCO COLLEGE OF ENGINEERING FATORDA-GOA. The Course under Civil Engineering, Mechanical Engineering & Electronic & Telecommunication Engineering are Accredited by National Board of Accredition (NBA) from 2022-23 to 2024-25 & Computer Engineering from 2023-24 to 2025-26.
                  .</p>

</div>
<hr class="blueline">
</body>

 <?php require 'utils/footer.php'; ?>

</html>