<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Resource - Inspirus 8</title>
    <?php require 'utils/styles.php'; ?>
</head>

<body>
    <?php include 'utils/adminHeader.php'; ?>

    <div class="container">
        <h2>Update Resource</h2>
        <?php
        include 'classes/db1.php';
        if (isset($_GET['req_id'])) {
            $req_id = $_GET['req_id'];
            $result = mysqli_query($conn, "SELECT * FROM resources WHERE req_id = '$req_id'");
            $resource = mysqli_fetch_array($result);
        }
        ?>
        <form method="POST" action="">
            <input type="hidden" name="req_id" value="<?php echo htmlspecialchars($resource['req_id']); ?>">
            <div class="form-group">
                <label>Resource Name:</label>
                <input type="text" name="r_name" required class="form-control" value="<?php echo htmlspecialchars($resource['r_name']); ?>">
            </div>

            <div class="form-group">
                <label>Type:</label>
                <input type="text" name="type" required class="form-control" value="<?php echo htmlspecialchars($resource['type']); ?>">
            </div>

            <div class="form-group">
                <label>Quantity:</label>
                <input type="number" name="quantity" required class="form-control" value="<?php echo htmlspecialchars($resource['quantity']); ?>">
            </div>

            <div class="form-group">
                <label>Event ID:</label>
                <input type="number" name="event_id" required class="form-control" value="<?php echo htmlspecialchars($resource['event_id']); ?>">
            </div>

            <button type="submit" name="updateResource" class="btn btn-primary">Update Resource</button>
            <a href="resources.php" class="btn btn-default">Back to Resources</a>
        </form>
    </div>

    <?php
    if (isset($_POST['updateResource'])) {
        $req_id = $_POST['req_id'];
        $r_name = $_POST['r_name'];
        $type = $_POST['type'];
        $quantity = $_POST['quantity'];
        $event_id = $_POST['event_id'];

        $updateQuery = "UPDATE resources SET 
                        r_name = '$r_name', type = '$type', quantity = $quantity, event_id = $event_id 
                        WHERE req_id = '$req_id'";

        if (mysqli_query($conn, $updateQuery)) {
            echo "<script>alert('Resource updated successfully!'); window.location.href='resources.php';</script>";
        } else {
            echo "<script>alert('Error updating resource: " . mysqli_error($conn) . "');</script>";
        }
    }
    ?>

    <?php include 'utils/footer.php'; ?>
</body>

</html>
